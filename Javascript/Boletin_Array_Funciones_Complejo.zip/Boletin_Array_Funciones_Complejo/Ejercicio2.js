/*
Partimos de:

let notas = [5.2, 3.9, 6, 9.75, 7.5, 3, 6.5, 9.75]

    Crea una función flecha aprobados que devuelva solo las notas ≥5.

    Usa reduce para calcular la nota media.

    Usa Math.max(...notas) para obtener la nota más alta.

    Crea un Set con las notas para eliminar duplicados.

    Con map, devuelve un array con las notas en formato "Nota: X".

    Con some, comprueba si hay algún suspenso (<5).

    Con every, comprueba si todas son ≥3.

*/

let notas = [5.2, 3.9, 6, 9.75, 7.5, 3, 6.5, 9.75];

const aprobados= () => {
    return notas.filter(nota => nota > 5);
}

console.log("Aprobados: " + aprobados());
console.log("Nota Media: " + notas.reduce(((accu,nota) => accu += nota),0)/notas.length);
console.log("Nota más alta: " + Math.max(...notas));
console.log("Notas sin duplicados: " + Array.from(new Set(notas)));
console.log("Notas en bonito: " + notas.map(nota => "Nota: " + nota));
console.log("Hay suspenso: " + notas.some(nota => nota<5));
console.log("Todas >= 3: " + notas.every(nota => nota>=3));